let questionCount = 1;

// تبديل عرض خيارات الاختيار من متعدد أو حقل الإجابة المقالية
function toggleOptions(selectElement) {
    const container = selectElement.closest('.question-container');
    const mcqOptions = container.querySelector('.mcq-options');
    const essayAnswer = container.querySelector('.essay-answer textarea');

    if (selectElement.value === 'mcq') {
        mcqOptions.style.display = 'block';
        essayAnswer.style.display = 'none';
    } else {
        mcqOptions.style.display = 'none';
        essayAnswer.style.display = 'block';
    }
}

// إضافة سؤال جديد
function addQuestion() {
    questionCount++;
    const template = document.querySelector('.question-container').cloneNode(true);
    template.setAttribute('data-question', questionCount);

    // تحديث رقم السؤال في النص
    const questionNumber = document.createElement('div');
    questionNumber.className = 'question-number';
    questionNumber.textContent = `السؤال ${questionCount}:`;
    template.prepend(questionNumber);

    // تحديث أسماء عناصر الإدخال
    template.querySelectorAll('input[type="radio"]').forEach(radio => {
        radio.name = `correct${questionCount}`;
    });

    // مسح الحقول
    template.querySelector('textarea').value = '';
    template.querySelectorAll('input[type="text"]').forEach(input => input.value = '');
    template.querySelector('.mcq-options').style.display = 'none';
    template.querySelector('.essay-answer textarea').style.display = 'block'; // عرض صندوق الإجابة المقالية بشكل افتراضي

    // إعادة تعيين نوع السؤال إلى "مقالي"
    template.querySelector('.questionType').value = 'essay';

    // إضافة السؤال الجديد إلى الحاوية
    document.getElementById('questionsContainer').appendChild(template);

    // تحديث أرقام الأسئلة
    updateQuestionNumbers();
}

// حذف سؤال
function deleteQuestion(button) {
    const container = button.closest('.question-container');
    container.remove();

    // تحديث أرقام الأسئلة بعد الحذف
    updateQuestionNumbers();
}

// تحديث أرقام الأسئلة
function updateQuestionNumbers() {
    const questions = document.querySelectorAll('.question-container');
    questions.forEach((question, index) => {
        const questionNumber = question.querySelector('.question-number');
        if (questionNumber) {
            questionNumber.textContent = `السؤال ${index + 1}:`;
        }
        question.setAttribute('data-question', index + 1);
    });
}

// منع إرسال النموذج وعرض رسالة نجاح
document.getElementById('examForm').addEventListener('submit', function(e) {
    e.preventDefault();
    console.log('تم حفظ الاختبار بنجاح');
});